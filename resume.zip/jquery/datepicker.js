var s = {
	dateFormat: "dd/mm/yy",
	minDate: 10,
	maxDate: "+10Y",
	autoSize: true
};

$(document).ready(function(){
	$("#date-picker").datepicker(s);
});



